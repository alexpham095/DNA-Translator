package com.translate;

public class TranslatorMaker {

	public static void main(String[] args) {	
		new UI();
	}
}
