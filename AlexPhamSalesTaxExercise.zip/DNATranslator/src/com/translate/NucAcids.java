package com.translate;

public interface NucAcids {
	void translate();
	
	String getSequence();
}
